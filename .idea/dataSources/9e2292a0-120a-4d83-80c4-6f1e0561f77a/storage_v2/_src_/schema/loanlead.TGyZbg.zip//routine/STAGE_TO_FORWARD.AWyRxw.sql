create
  definer = root@localhost function STAGE_TO_FORWARD(loan_id int) returns int
BEGIN

    DECLARE loan_type VARCHAR(20);

    DECLARE loan_amount INT;

    DECLARE loan_stage_id INT;



    SELECT lp.loan_type, l.amount, r.id INTO loan_type, loan_amount, loan_stage_id

    FROM loan_products AS lp,

         loans AS l,

         users AS u,

         roles AS r

    WHERE lp.loan_product = l.loan_product AND

          l.id = loan_id AND

          l.actioned_by = u.employee_id AND u.role_id = r.name;



    IF loan_type = 'MSE' THEN

      IF loan_stage_id < 5 THEN

        RETURN loan_stage_id + 2;

      ELSEIF loan_stage_id = 5 THEN

        RETURN 9;

      ELSE

        RETURN loan_stage_id + 1;

      END IF;

    ELSE

      IF loan_amount < 3000000 THEN

        IF loan_stage_id < 3 THEN

          RETURN loan_stage_id + 1;

        ELSEIF loan_stage_id < 5 THEN

          RETURN 5;

        ELSEIF loan_stage_id < 8 THEN

          RETURN 8;

        ELSE

          RETURN loan_stage_id + 1;

        END IF;

      ELSEIF loan_amount < 10000000 THEN

        IF loan_stage_id < 5 THEN

          RETURN loan_stage_id + 1;

        ELSEIF loan_stage_id < 8 THEN

          RETURN 8;

        ELSE

          RETURN loan_stage_id + 1;

        END IF;

      ELSE

        RETURN loan_stage_id + 1;

      END IF;

    END IF;

  END;

