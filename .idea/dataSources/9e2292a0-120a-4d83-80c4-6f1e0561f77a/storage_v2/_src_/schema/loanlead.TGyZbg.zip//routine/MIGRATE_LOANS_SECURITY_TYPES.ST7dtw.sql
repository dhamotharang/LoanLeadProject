create
  definer = root@localhost procedure MIGRATE_LOANS_SECURITY_TYPES()
BEGIN

    DECLARE loan_id INT;

    DECLARE cursor_done TINYINT(1);

    DECLARE loans_cursor CURSOR FOR SELECT id FROM loans;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET cursor_done = 1;



    DELETE FROM loans_security_types;



    OPEN loans_cursor;

    loans_iterator: LOOP

      FETCH loans_cursor INTO loan_id;



      IF cursor_done THEN

        LEAVE loans_iterator;

      END IF;



      CALL MIGRATE_LOANS_SECURITY_TYPES_BY_LOAN_ID(loan_id);

    END LOOP;

    CLOSE loans_cursor;

  END;

