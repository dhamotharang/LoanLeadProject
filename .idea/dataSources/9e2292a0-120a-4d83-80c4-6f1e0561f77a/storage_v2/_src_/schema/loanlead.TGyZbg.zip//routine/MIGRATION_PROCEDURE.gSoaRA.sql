create
  definer = root@localhost procedure MIGRATION_PROCEDURE()
BEGIN

    

    CALL REMOVE_REPEATED_CUSTOMERS();



    

    DELETE FROM phone_numbers;



    INSERT INTO phone_numbers(first_phone_number, second_phone_number)

    SELECT IF(phone_number1 = '', id, phone_number1), IF(phone_number2 = '', id, phone_number2) FROM previous_loanlead.users UNION

    SELECT phone_number1, phone_number2 FROM previous_loanlead.customers;



    

    DELETE FROM entities;



    INSERT INTO entities(id, name, short_name, box_number, plot_number, branches_number, description, created_at)

    SELECT e.id, TRIM(e.name), e.short_name, e.box_number, e.plot_number, e.branches_number, e.description, e.created_at

    FROM previous_loanlead.entities AS e;



    

    DELETE FROM branches;



    INSERT INTO branches(id, entity_name, name, type, district, town, created_at)

    SELECT b.id, e.name, b.name, b.type, b.district, b.town, b.created_at

    FROM previous_loanlead.branches AS b,
        entities AS e

    WHERE e.id = b.entity_id;



    

    DELETE FROM roles;



    INSERT INTO roles(id, name, display_name)

    SELECT id, name, display_name FROM previous_loanlead.roles;



    

    DELETE FROM users;



    INSERT INTO users(id, employee_id, phone_numbers_id, password, full_name, email, status, picture_path, updated_at, status_change_timestamp, created_at, newly_created)

    SELECT u.id, CONCAT(u.employee_id, u.id), p.id, u.password, u.full_name, u.email, u.status, u.picture_path, u.updated_at, CURRENT_TIMESTAMP, u.created_at, 0

    FROM previous_loanlead.users AS u,

         phone_numbers AS p

    WHERE p.first_phone_number = u.phone_number1 AND p.second_phone_number = u.phone_number2;



    
    DELETE FROM users_branches;



    INSERT INTO users_branches(employee_id, branch_name)

    SELECT u.employee_id, b.name

    FROM users AS u,

    		 branches AS b,

         previous_loanlead.users AS pu

	 	WHERE u.id = pu.id AND pu.branch_id = b.id;




	 	DELETE FROM users_roles;



    INSERT INTO users_roles(employee_id, role_name)

    SELECT u.employee_id, r.name

    FROM users AS u,

    		 roles AS r,

         previous_loanlead.users AS pu

	 	WHERE u.id = pu.id AND pu.role_id = r.id;




    DELETE FROM customers;



    INSERT INTO customers(id, phone_numbers_id, name, document, document_type, created_at)

    SELECT c.id, p.id, c.name, c.document, c.document_type, c.created_at

    FROM previous_loanlead.customers AS c,

         phone_numbers AS p

    WHERE p.first_phone_number = c.phone_number1 AND p.second_phone_number = c.phone_number2 AND c.document != '';



    

    DELETE FROM loan_types;



    INSERT INTO loan_types(loan_type) VALUES ('MSE'), ('DAS'), ('Group Loans');



    

    DELETE FROM loan_products;



    INSERT INTO loan_products(id, loan_product, loan_type, max_amount, max_tenure, time_threshold)

    SELECT lt.id, lt.type, IF(lt.type LIKE 'Group Loans', 'Group Loans', IF(lt.type LIKE 'DAS', 'DAS', 'MSE')), lt.amount, lt.tenure, lt.time_threshold

    FROM previous_loanlead.loan_thresholds AS lt;


    DELETE FROM loans;



    INSERT INTO loans(id, customer_id, loan_product, actioned_by, stage, amount, tenure, created_at, receive_timestamp, defer_stage, type_changed, staged_at, comment, status)

    SELECT l.id, l.customer_id, lp.loan_product, u.employee_id, r.name, l.amount, l.tenure, l.created_at, l.receive_timestamp, l.stage_deferred, l.type_changed, l.stage_timestamp, l.comment, l.status

    FROM previous_loanlead.loans AS l,
         loan_products AS lp,
         users AS u,
         roles AS r,
         customers AS c

    WHERE u.id = l.staged_by AND
          lp.id = l.loan_threshold_id AND
          r.id = l.stage AND 
          l.customer_id = c.id;
    

    DELETE FROM security_types;



    INSERT INTO security_types(security_type)

    VALUES ('Household chattels'),

           ('Motor vehicle'),

           ('Land sale agreement'),

           ('Land title'),

           ('Equipment'),

           ('Cash'),

           ('Salary'),

           ('Group guarantee'),

           ('Unsecure');



    

    DELETE FROM loans_security_types;



    CALL MIGRATE_LOANS_SECURITY_TYPES();



    

    DELETE FROM reports;



    INSERT INTO reports(id, loan_id, status, comment, actioned_at, actioned_by)

    SELECT a.id, l.id, a.status, a.comment, a.created_at, u.employee_id

    FROM previous_loanlead.auditing AS a,
         loans AS l,
         users AS u

    WHERE u.id = a.action_by AND l.id = a.loan_id;

  END;

