create
  definer = root@localhost procedure MIGRATE_LOANS_SECURITY_TYPES_BY_LOAN_ID(IN loan_id int)
BEGIN

    DECLARE security_type_id INT;

    DECLARE security_type_value VARCHAR(50);

    DECLARE security_types_string VARCHAR(100);



    SELECT l.security_type INTO security_types_string

      FROM previous_loanlead.loans AS l

      WHERE l.id = loan_id;



    security_types_iterator: LOOP

      SET security_type_value = SUBSTRING_INDEX(security_types_string, ';', 1);

      SELECT id INTO security_type_id

        FROM security_types

        WHERE security_type = security_type_value;

      INSERT INTO loans_security_types(loan_id, security_type_id)

        VALUES (loan_id, security_type_id);



      SET security_types_string = SUBSTRING(

          security_types_string,

          LENGTH(security_type_value) + 2

      );



      IF POSITION(';' IN security_types_string) = 0 THEN

        LEAVE security_types_iterator;

      END IF;

    END LOOP;

  END;

