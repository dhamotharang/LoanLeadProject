create
  definer = root@localhost procedure REMOVE_REPEATED_CUSTOMERS()
BEGIN

    DECLARE repeated_document VARCHAR(50);

    DECLARE first_customer_id INT;

    DECLARE cursor_done TINYINT(1);

    DECLARE repeated_documents_cursor CURSOR FOR SELECT document, id FROM previous_loanlead.customers GROUP BY document HAVING COUNT(*) = 2;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET cursor_done = 1;



    OPEN repeated_documents_cursor;

      repeated_document_loop: LOOP

        FETCH repeated_documents_cursor INTO repeated_document, first_customer_id;



        IF cursor_done THEN

          LEAVE repeated_document_loop;

        END IF;



        UPDATE previous_loanlead.loans AS l, previous_loanlead.customers AS c

        SET l.customer_id = first_customer_id

        WHERE l.customer_id = c.id AND c.document = repeated_document AND c.id != first_customer_id;



        DELETE FROM previous_loanlead.customers WHERE document = repeated_document AND id != first_customer_id;

      END LOOP;

    CLOSE repeated_documents_cursor;

  END;

