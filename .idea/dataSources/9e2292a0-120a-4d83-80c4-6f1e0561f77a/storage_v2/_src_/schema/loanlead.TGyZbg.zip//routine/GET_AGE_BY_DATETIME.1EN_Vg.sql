create
  definer = root@localhost function GET_AGE_BY_DATETIME(specific_datetime datetime) returns varchar(20)
BEGIN

    DECLARE difference_in_days INT;



    SELECT DATEDIFF(CURRENT_TIMESTAMP, specific_datetime) INTO difference_in_days;



    RETURN CONCAT(

        FLOOR(difference_in_days / 7),

        ' weeks ',

        difference_in_days - FLOOR(difference_in_days / 7) * 7,

        ' days'

    );

  END;

